Solutions to the Test First Learn Ruby sequence

	-These exercises involved cloning the Github repo and programming in Ruby to the given tests
	on http://testfirst.org/. Some of the more interesting problems include but are not limited to:
			- writing a performance monitor
			- writing a reverse polish notation calculator
  	        - writing an extension to Fixnum to print numbers in English.
			-writing a temperature converter using Object Oriented Programming.
