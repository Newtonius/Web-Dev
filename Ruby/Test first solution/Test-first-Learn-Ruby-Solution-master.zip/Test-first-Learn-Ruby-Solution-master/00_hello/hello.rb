def hello
	"Hello!"
end

def greet(who)
"Hello, #{who}!"
end
